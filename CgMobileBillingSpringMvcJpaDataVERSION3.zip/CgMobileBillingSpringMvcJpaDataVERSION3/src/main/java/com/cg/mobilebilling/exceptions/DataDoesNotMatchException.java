package com.cg.mobilebilling.exceptions;
@SuppressWarnings("serial")
public class DataDoesNotMatchException extends Exception {
	public DataDoesNotMatchException() {
		super();
	}
	public DataDoesNotMatchException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public DataDoesNotMatchException(String message, Throwable cause) {
		super(message, cause);
	}
	public DataDoesNotMatchException(String message) {
		super(message);
	}
	public DataDoesNotMatchException(Throwable cause) {
		super(cause);
	}
	
}
