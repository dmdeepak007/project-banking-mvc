package com.cg.mobilebilling.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.DataDoesNotMatchException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException   {
		int customerID = billingServices.acceptCustomerDetails(customer.getFirstName(), customer.getLastName(), customer.getEmailID(), customer.getDateOfBirth(), customer.getBillingAddress().getCity(), customer.getBillingAddress().getState(), customer.getBillingAddress().getPinCode());
		return new ModelAndView("registrationSuccessPage", "customerID", customerID);
	}

	@RequestMapping("/openPostpaidAccount")
	public ModelAndView openPostpaidAccountAction(@Valid @RequestParam("planID") int planID, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		long mobileNo = billingServices.openPostpaidMobileAccount(customer.getCustomerID(),planID);
		ModelAndView model = new ModelAndView("planDetailsPage","mobileNo",mobileNo);
		return model;
	}

	@RequestMapping("/show")
	public ModelAndView showPlanAction(@Valid @ModelAttribute Plan plan,
			BindingResult result) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		List<Plan> plans = billingServices.addPlanDetails(plan);
		ModelAndView model = new ModelAndView("showPlan","plans",plans);
		return model;	
	}



	@RequestMapping("customerDetails")
	public ModelAndView customerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer1 = billingServices.getCustomerDetails(customer.getCustomerID());
		ModelAndView model = new ModelAndView("getCustomerDetailsPage","customer1",customer1);
		model.addObject("open","1");
				return model;

			}
	
	@RequestMapping("allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		List<Customer> lists = billingServices.getAllCustomerDetails();
		ModelAndView model = new ModelAndView("getAllCustomerDetailsPage","lists",lists);
		model.addObject("open","1");
				return model;

			}

	@RequestMapping("postpaidAccountDetails")
	public ModelAndView postpaidAccountDetailsAction(@Valid @RequestParam("mobileNo") int mobileNo, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
	PostpaidAccount postpaid = 	billingServices.getPostPaidAccountDetails(customer.getCustomerID(), mobileNo);
		ModelAndView model = new ModelAndView("getPostPaidAccountDetailsPage","postpaid",postpaid);
		model.addObject("open","1");
		return model;

			}

	@RequestMapping("customerPostPaidAccountPlanDetails")
	public ModelAndView customerPostPaidAccountPlanDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException, CustomerDetailsNotFoundException {
		
		List<PostpaidAccount> lists = billingServices.getCustomerAllPostpaidAccountsDetails(customer.getCustomerID());
		ModelAndView model = new ModelAndView("getCustomerPostPaidAccountPlanDetailsPage","lists",lists);
		model.addObject("open","1");
		return model;
			}


	@RequestMapping("planChange")
	public ModelAndView planChangeAction(@Valid @RequestParam("mobileNo") int mobileNo, @RequestParam("planID") int planID, @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		try {
			billingServices.changePlan(customer.getCustomerID(), mobileNo, planID);
			ModelAndView model = new ModelAndView("changePlanPage","message","Mobile Plan has successfully updated.");
			return model;
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | PlanDetailsNotFoundException | DataDoesNotMatchException e) {
			return new ModelAndView("changePlanPage","message",e.getMessage());
						
		}
			}

	
	
	/*
	@RequestMapping("deleteCustomerAccount")
	public ModelAndView deleteCustomerAccountAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("deleteCustomerPage");
				return null;

			}



	@RequestMapping("mobileBillDetails")
	public ModelAndView mobileBillDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getMobileBillDetailsPage");
				return null;

			}

	@RequestMapping("customerPostPaidAccountAllBillDetails")
	public ModelAndView customerPostPaidAccountAllBillDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("getCustomerPostPaidAccountAllBillDetailsPage");
				return null;

			}

	@RequestMapping("generateMonthlyBill")
	public ModelAndView generateMonthlyMobileAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) throws BillingServicesDownException {
		ModelAndView model = new ModelAndView("generateMonthlyMobileBillPage");
				return null;

			}*/
}
