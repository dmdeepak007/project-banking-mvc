package com.cg.banking.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public interface AccountDAO extends JpaRepository<Account, Integer> {
	/*Account saveAccount(Account account);
	Account findOne(int accountNo);
	List<Account> findAllAccounts();
	List<Transaction> fetchAllTransactions(int accountNo);
	Account fetchAccountStatus(int accountNo);
	Account depositAmountToAccount(int accountNo, float amount);
	Account withdrawFromAccount(int accountNo, float amount, int pinNumber);
	Account setAccountStatus(int accountNo, String status);
	Account changePIN(int accountNo, int pin);
	int fetchPinTries(int accountNo);
	boolean setPinTries(int accountNo, int pinTry);
	boolean deactivateAccount(int accountNo);
	Account update(Account account);
	Transaction saveTransaction(int accountNo, String transactionType, float amount);*/
}