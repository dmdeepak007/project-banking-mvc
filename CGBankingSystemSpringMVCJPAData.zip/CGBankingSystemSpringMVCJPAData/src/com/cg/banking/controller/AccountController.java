package com.cg.banking.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.services.BankingServices;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Controller
public class AccountController {

	@Autowired
	private BankingServices bankingServices;
	
	@RequestMapping("/openaccount1")
	public ModelAndView registerAccountAction(@Valid @ModelAttribute Account account, BindingResult result)
			throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		
	account = bankingServices.openAccount(account);
	return new ModelAndView("openAccountSuccessPage","account",account);
	}
	
	@RequestMapping("/depositamount1")
	public ModelAndView depositAmountAction(@Valid @ModelAttribute Account account, BindingResult result)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException{
		
	float amount = bankingServices.depositAmount(account.getAccountNo(), account.getTransactions().get(0).getAmount());
	return new ModelAndView("depositamount","amount","Amount Successfully deposited. Your updated balance is "+ amount);
	}
	
	@RequestMapping("/withdrawamount1")
	public ModelAndView withdrawAmountAction(@Valid @ModelAttribute Account account, BindingResult result)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		
	float amount = bankingServices.withdrawAmount(account.getAccountNo(), account.getTransactions().get(0).getAmount(),account.getPinNumber());
	return new ModelAndView("withdrawamount","amount","Amount Successfully Withdrawn. Your updated balance is "+ amount);
	}
	
	@RequestMapping("/fundtransfer1")
	public ModelAndView fundtransferAction(@Valid @ModelAttribute Account account, @RequestParam("accountNoTo") int accountNoTo, BindingResult result)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
	float amount = account.getTransactions().get(0).getAmount();
	bankingServices.fundTransfer(accountNoTo, account.getAccountNo(), account.getTransactions().get(0).getAmount(), account.getPinNumber());
	return new ModelAndView("fundtransfer","amount","Amount "+amount+ " Successfully Transferred.");
	}
	
	@RequestMapping("/specificaccountdetail1")
	public ModelAndView specificaccountdetailAction(@Valid @ModelAttribute Account account, BindingResult result)
			throws BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException{
		
	Account account2 = bankingServices.getAccountDetails(account.getAccountNo());
	ModelAndView model = new ModelAndView("specificaccountdetail");
	model.addObject("account2",account2);
	model.addObject("open","1");
	return model;
	}
	
	
	
	
	
	
}
