package com.cg.banking.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;


@Controller
public class URIController {

	Account account;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/openaccount")
	public String getOpenAccountPage() {
		return "openaccount";
	}
	
	@RequestMapping("/depositamount")
	public String getDepositAmountPage() {
		return "depositamount";
	}
	
	@RequestMapping("/withdrawamount")
	public String getWithdrawAmountPage() {
		return "withdrawamount";
	}
	
	@RequestMapping("/fundtransfer")
	public String getFundTransferPage() {
		return "fundtransfer";
	}
	
	@RequestMapping("/specificaccountdetail")
	public String getSpecificAccountDetailPage() {
		return "specificaccountdetail";
	}
	
	@RequestMapping("/allaccountdetails")
	public String getAllAccountDetailsPage() {
		return "allaccountdetails";
	}
	
	@RequestMapping("/transactiondetails")
	public String getTransactionDetailsPage() {
		return "transactiondetails";
	}
	
	@RequestMapping("/customercare")
	public String getCustomerCarePage() {
		return "customercare";
	}
	
	@ModelAttribute
	public Account getAccount() {
		account= new Account();
		return account;
	}	
}
